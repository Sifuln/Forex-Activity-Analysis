package com.sobuz.dailyfxsignal;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class UserAdapter extends ArrayAdapter<User> {

    public UserAdapter(Context context, ArrayList<User> users){
        super(context,0,users);
    }

    @Override
    public View getView(int position,View convertView,ViewGroup parent) {
        User user = getItem(position);

        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.signal_info,parent,false);
        }

        TextView title = (TextView) convertView.findViewById(R.id.textCurrency);
        TextView status = (TextView) convertView.findViewById(R.id.textStatus);
        TextView benefit = (TextView) convertView.findViewById(R.id.textBenefit);
        TextView signal = (TextView) convertView.findViewById(R.id.textSignal);

        title.setText(user.title);
        status.setText(user.status);
        benefit.setText(user.benefit);
        signal.setText(user.signal);
        return  convertView;
    }
}
