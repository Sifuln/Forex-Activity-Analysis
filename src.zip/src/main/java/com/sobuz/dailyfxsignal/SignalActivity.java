package com.sobuz.dailyfxsignal;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class SignalActivity extends AppCompatActivity {

    private TextView signalTitle,openPrice,takeProfit1,takeProfit2,stopLoss,closePrice,benefit,textSignal,textStatus,textDate,textSignalValue;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private AdView mAdView;
    private DecimalFormat df;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signal);
        //no internet
        if(!isConnected(SignalActivity.this)) buildDialog(SignalActivity.this).show();


        //decimal value increase
        df = new DecimalFormat("#0.00000");

        signalTitle = (TextView) findViewById(R.id.texTitle);
        openPrice = (TextView) findViewById(R.id.textOpenPriceValue);
        takeProfit1 = (TextView) findViewById(R.id.textTakeProfitValue1);
        takeProfit2 = (TextView) findViewById(R.id.textTakeProfitValue2);
        stopLoss = (TextView) findViewById(R.id.textStopLossValue);
        textSignalValue = (TextView) findViewById(R.id.textSignalValue);
        benefit = (TextView) findViewById(R.id.textBenefit);
        textSignal = (TextView) findViewById(R.id.textStatusValue);
        textStatus = (TextView) findViewById(R.id.textStatus);
        textDate = (TextView) findViewById(R.id.textDateValue);

        final String title = getIntent().getStringExtra("title_ref");
        //admob
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);



        //initialise firebase
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("User");
        databaseReference.child(title).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user = dataSnapshot.getValue(User.class);
                String openP = String.valueOf(df.format(user.open_price));
                String takeP1 = String.valueOf(df.format(user.takeProfit1));
                String takep2 = String.valueOf(df.format(user.takeProfit2));
                String stopL = String.valueOf(df.format(user.stopLoss));
                signalTitle.setText(user.title);
                textSignalValue.setText(user.signal);
                textSignal.setText(user.status);
                //textStatus.setText(user.status);
                openPrice.setText(openP);
                takeProfit1.setText(takeP1);
                takeProfit2.setText(takep2);
                stopLoss.setText(stopL);
                //closePrice.setText(user.closePrice);
                benefit.setText(user.benefit);
                textDate.setText(user.date);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    public boolean isConnected(Context context){
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netinfo = cm.getActiveNetworkInfo();
        if (netinfo != null && netinfo.isConnectedOrConnecting()){
            android.net.NetworkInfo wifi = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            android.net.NetworkInfo mobile = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            if ((mobile !=null && mobile.isConnectedOrConnecting()) || (wifi != null && wifi.isConnectedOrConnecting()))
                return true;
            else
                return false;
        }else
            return false;
    }

    public AlertDialog.Builder buildDialog(Context context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("No Internet Connection");
        builder.setMessage("Press ok to Exit");

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        return builder;
    }


}
