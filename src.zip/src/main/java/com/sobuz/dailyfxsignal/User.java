package com.sobuz.dailyfxsignal;

public class User {

    public  String title;
    public  String status;
    public  String benefit;
    public  String signal;
    public Double open_price,takeProfit1,takeProfit2,stopLoss;
    public String closePrice,date;
    public User(){

    }

    public User(String title, String status, String benefit, String signal) {
        this.title = title;
        this.status = status;
        this.benefit = benefit;
        this.signal = signal;
        open_price = 1.0;
        takeProfit1 = 1.0;
        takeProfit2 = 1.0;
        stopLoss = 1.0;
        closePrice = "";
        date = "";
    }


}
